from setuptools import setup, find_packages

setup(
    name='profiler_framework',
    version='1.0.0',
    description='A Python framework for memory and CPU profiling.',
    author='Your Name',
    author_email='your_email@example.com',
    packages=find_packages(),
    install_requires=[
        'psutil',
        'seaborn',
        'matplotlib',
    ],
    classifiers=[
        'Programming Language :: Python :: 3',
        '..',
        'Operating System :: OS Independent',
    ],
    python_requires='>=3.6',
)